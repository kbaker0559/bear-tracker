const CACHE_NAME = 'bear-tracker-shell-v07';
const ASSETS = [
  '/bear-tracker/',
  '/bear-tracker/manifest.webmanifest',
  '/bear-tracker/icon-192.png',
  '/bear-tracker/icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)).catch(() => undefined));
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))))
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(fetch(event.request).catch(() => caches.match(event.request).then(cached => cached || caches.match('/bear-tracker/'))));
});
