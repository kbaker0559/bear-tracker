import { useEffect, useMemo, useState } from 'react';
import type { Group, Player } from '../types';

type Props = {
  groups: Group[];
  players: Player[];

  onMovePlayer: (
    playerId: string,
    fromGroupId: string,
    toGroupId: string
  ) => void;

  onSwapPlayers: (
    firstPlayerId: string,
    secondPlayerId: string
  ) => void;

  onChangeScorekeeper: (
    groupId: string,
    playerId: string
  ) => void;

  onReorderScorecard: (
    groupId: string,
    orderedPlayerIds: string[]
  ) => void;
  initialStage?: 'changes' | 'order';
  onFinishChanges: () => void;
  onFinishOrder: () => void;
};

type PlayerAction = 'move' | 'swap' | null;

export default function SaturdayPairingManager({
  groups,
  players,
  onMovePlayer,
  onSwapPlayers,
  onChangeScorekeeper,
  onReorderScorecard,
  initialStage = 'changes',
  onFinishChanges,
  onFinishOrder
}: Props) {
  const [stage, setStage] =
    useState<'changes' | 'order'>(initialStage);
  const [activePlayerId, setActivePlayerId] =
    useState<string | null>(null);

  const [activeAction, setActiveAction] =
    useState<PlayerAction>(null);

  const [destinationGroupId, setDestinationGroupId] =
    useState('');

  const [swapPlayerId, setSwapPlayerId] =
    useState('');

  useEffect(() => {
    setStage(initialStage);
    setActivePlayerId(null);
    setActiveAction(null);
    setDestinationGroupId('');
    setSwapPlayerId('');
  }, [initialStage]);

  const activePlayer =
    players.find(
      (player) => player.id === activePlayerId
    ) ?? null;

  const activeGroup = useMemo(
    () =>
      groups.find((group) =>
        activePlayerId
          ? group.playerIds.includes(activePlayerId)
          : false
      ) ?? null,
    [groups, activePlayerId]
  );

  const swapOptions = useMemo(() => {
    if (!activeGroup) {
      return [];
    }

    return groups
      .filter((group) => group.id !== activeGroup.id)
      .flatMap((group) =>
        group.playerIds.map((playerId) => {
          const player = players.find(
            (candidate) => candidate.id === playerId
          );

          return {
            playerId,
            groupId: group.id,
            groupName: group.name.replace(
              'Group',
              'Card'
            ),
            playerName: player?.name ?? playerId
          };
        })
      );
  }, [groups, players, activeGroup]);

  function playerName(playerId: string): string {
    return (
      players.find(
        (player) => player.id === playerId
      )?.name ?? playerId
    );
  }

  function closePlayerActions() {
    setActivePlayerId(null);
    setActiveAction(null);
    setDestinationGroupId('');
    setSwapPlayerId('');
  }

  function openPlayerActions(playerId: string) {
    if (activePlayerId === playerId) {
      closePlayerActions();
      return;
    }

    setActivePlayerId(playerId);
    setActiveAction(null);
    setDestinationGroupId('');
    setSwapPlayerId('');
  }

  function openMove() {
    setActiveAction('move');
    setDestinationGroupId('');
    setSwapPlayerId('');
  }

  function openSwap() {
    setActiveAction('swap');
    setDestinationGroupId('');
    setSwapPlayerId('');
  }

  function confirmMove() {
    if (
      !activePlayerId ||
      !activeGroup ||
      !destinationGroupId
    ) {
      return;
    }

    onMovePlayer(
      activePlayerId,
      activeGroup.id,
      destinationGroupId
    );

    closePlayerActions();
  }

  function confirmSwap() {
    if (
      !activePlayerId ||
      !swapPlayerId
    ) {
      return;
    }

    onSwapPlayers(
      activePlayerId,
      swapPlayerId
    );

    closePlayerActions();
  }

  function makeScorekeeper() {
    if (
      !activePlayerId ||
      !activeGroup
    ) {
      return;
    }

    onChangeScorekeeper(
      activeGroup.id,
      activePlayerId
    );

    closePlayerActions();
  }

  function movePlayerInOrder(
    groupId: string,
    playerId: string,
    direction: 'up' | 'down'
  ) {
    const group = groups.find(
      (candidate) => candidate.id === groupId
    );

    if (!group) {
      return;
    }

    const currentIndex =
      group.playerIds.indexOf(playerId);

    if (currentIndex < 0) {
      return;
    }

    const nextIndex =
      direction === 'up'
        ? currentIndex - 1
        : currentIndex + 1;

    if (
      nextIndex < 0 ||
      nextIndex >= group.playerIds.length
    ) {
      return;
    }

    const orderedPlayerIds =
      [...group.playerIds];

    [
      orderedPlayerIds[currentIndex],
      orderedPlayerIds[nextIndex]
    ] = [
      orderedPlayerIds[nextIndex],
      orderedPlayerIds[currentIndex]
    ];

    onReorderScorecard(
      groupId,
      orderedPlayerIds
    );
  }

  return (
    <section className="card">
      <p className="eyebrow">
        {stage === 'changes' ? 'Step 1 of 2' : 'Step 2 of 2'}
      </p>

      <h2>
        {stage === 'changes'
          ? 'Review Pairing Changes'
          : 'Reorganize Scorecard Order'}
      </h2>

      <p>
        {stage === 'changes'
          ? 'Make Saturday-morning changes first: move or swap players and select the scorekeeper. These changes update the official scorecards used for score entry.'
          : 'Arrange each card so the names match the order written on the paper scorecard.'}
      </p>

      <div className="score-grid">
        {groups.map((group) => {
          const scorekeeperId =
            group.scorekeeperIds[0];

          return (
            <section
              className="card"
              key={group.id}
            >
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  gap: '1rem',
                  flexWrap: 'wrap'
                }}
              >
                <div>
                  <h3
                    style={{
                      marginTop: 0,
                      marginBottom: '0.25rem'
                    }}
                  >
                    {group.name.replace(
                      'Group',
                      'Card'
                    )}
                  </h3>

                  <div>
                    {group.playerIds.length}{' '}
                    {group.playerIds.length === 1
                      ? 'player'
                      : 'players'}
                  </div>
                </div>

                <div>
                  <strong>Scorekeeper:</strong>{' '}
                  {scorekeeperId
                    ? playerName(scorekeeperId)
                    : 'Not assigned'}
                </div>
              </div>

              <div
                style={{
                  marginTop: '1rem'
                }}
              >
                {group.playerIds.map((playerId, playerIndex) => {
                  const isScorekeeper =
                    scorekeeperId === playerId;

                  const actionsOpen =
                    activePlayerId === playerId;

                  return (
                    <div
                      key={playerId}
                      style={{
                        borderTop:
                          '1px solid rgba(0, 0, 0, 0.12)',
                        padding: '0.75rem 0'
                      }}
                    >
                      <div
                        style={{
                          display: 'flex',
                          justifyContent:
                            'space-between',
                          alignItems: 'center',
                          gap: '1rem',
                          flexWrap: 'wrap'
                        }}
                      >
                        <div>
                          <strong>
                            {playerName(playerId)}
                          </strong>

                          {isScorekeeper && (
                            <span>
                              {' '}
                              — Scorekeeper
                            </span>
                          )}
                        </div>

                        <div
                          style={{
                            display: 'flex',
                            gap: '0.5rem',
                            flexWrap: 'wrap'
                          }}
                        >
                          {stage === 'order' && (
                            <>
                              <button
                                type="button"
                                disabled={playerIndex === 0}
                                onClick={() =>
                                  movePlayerInOrder(
                                    group.id,
                                    playerId,
                                    'up'
                                  )
                                }
                              >
                                Move Up
                              </button>

                              <button
                                type="button"
                                disabled={
                                  playerIndex ===
                                  group.playerIds.length - 1
                                }
                                onClick={() =>
                                  movePlayerInOrder(
                                    group.id,
                                    playerId,
                                    'down'
                                  )
                                }
                              >
                                Move Down
                              </button>
                            </>
                          )}

                          {stage === 'changes' && (
                            <button
                              type="button"
                              onClick={() =>
                                openPlayerActions(playerId)
                              }
                            >
                              {actionsOpen
                                ? 'Close Actions'
                                : 'Change Player'}
                            </button>
                          )}
                        </div>
                      </div>

                      {stage === 'changes' &&
                        actionsOpen &&
                        activePlayer &&
                        activeGroup && (
                          <div
                            style={{
                              marginTop: '0.75rem',
                              padding: '0.75rem',
                              border:
                                '1px solid rgba(0, 0, 0, 0.12)',
                              borderRadius: '0.5rem'
                            }}
                          >
                            <div
                              style={{
                                display: 'flex',
                                gap: '0.75rem',
                                flexWrap: 'wrap'
                              }}
                            >
                              <button
                                type="button"
                                onClick={openMove}
                              >
                                Move
                              </button>

                              <button
                                type="button"
                                onClick={openSwap}
                              >
                                Swap
                              </button>

                              <button
                                type="button"
                                disabled={isScorekeeper}
                                onClick={makeScorekeeper}
                              >
                                {isScorekeeper
                                  ? 'Current Scorekeeper'
                                  : 'Make Scorekeeper'}
                              </button>
                            </div>

                            {activeAction === 'move' && (
                              <div
                                style={{
                                  marginTop: '1rem'
                                }}
                              >
                                <label>
                                  <strong>
                                    Move {activePlayer.name} to
                                  </strong>

                                  <select
                                    value={
                                      destinationGroupId
                                    }
                                    onChange={(event) =>
                                      setDestinationGroupId(
                                        event.target.value
                                      )
                                    }
                                    style={{
                                      display: 'block',
                                      width: '100%',
                                      marginTop: '0.5rem',
                                      marginBottom: '0.75rem',
                                      padding: '0.75rem',
                                      fontSize: '1rem'
                                    }}
                                  >
                                    <option value="">
                                      Select destination card
                                    </option>

                                    {groups
                                      .filter(
                                        (
                                          destinationGroup
                                        ) =>
                                          destinationGroup.id !==
                                          activeGroup.id
                                      )
                                      .map(
                                        (
                                          destinationGroup
                                        ) => (
                                          <option
                                            key={
                                              destinationGroup.id
                                            }
                                            value={
                                              destinationGroup.id
                                            }
                                          >
                                            {destinationGroup.name.replace(
                                              'Group',
                                              'Card'
                                            )}{' '}
                                            —{' '}
                                            {
                                              destinationGroup
                                                .playerIds
                                                .length
                                            }{' '}
                                            players
                                          </option>
                                        )
                                      )}
                                  </select>
                                </label>

                                <button
                                  type="button"
                                  disabled={
                                    !destinationGroupId
                                  }
                                  onClick={confirmMove}
                                >
                                  Confirm Move
                                </button>
                              </div>
                            )}

                            {activeAction === 'swap' && (
                              <div
                                style={{
                                  marginTop: '1rem'
                                }}
                              >
                                <label>
                                  <strong>
                                    Swap {activePlayer.name} with
                                  </strong>

                                  <select
                                    value={swapPlayerId}
                                    onChange={(event) =>
                                      setSwapPlayerId(
                                        event.target.value
                                      )
                                    }
                                    style={{
                                      display: 'block',
                                      width: '100%',
                                      marginTop: '0.5rem',
                                      marginBottom: '0.75rem',
                                      padding: '0.75rem',
                                      fontSize: '1rem'
                                    }}
                                  >
                                    <option value="">
                                      Select another player
                                    </option>

                                    {swapOptions.map(
                                      (option) => (
                                        <option
                                          key={
                                            option.playerId
                                          }
                                          value={
                                            option.playerId
                                          }
                                        >
                                          {
                                            option.playerName
                                          }{' '}
                                          —{' '}
                                          {
                                            option.groupName
                                          }
                                        </option>
                                      )
                                    )}
                                  </select>
                                </label>

                                <button
                                  type="button"
                                  disabled={!swapPlayerId}
                                  onClick={confirmSwap}
                                >
                                  Confirm Swap
                                </button>
                              </div>
                            )}
                          </div>
                        )}
                    </div>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>

      <div
        style={{
          marginTop: '1.5rem',
          display: 'flex',
          justifyContent: 'flex-end',
          gap: '0.75rem',
          flexWrap: 'wrap'
        }}
      >
        {stage === 'changes' && (
          <button type="button" onClick={onFinishChanges}>
            Player Status Complete — Reorganize Scorecards
          </button>
        )}

        {stage === 'order' && (
          <button type="button" onClick={onFinishOrder}>
            Scorecard Order Complete — Begin Player Arrivals
          </button>
        )}
      </div>
    </section>
  );
}
